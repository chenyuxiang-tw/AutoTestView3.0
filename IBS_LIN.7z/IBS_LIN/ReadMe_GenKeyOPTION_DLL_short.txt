*** GenKeyOPTION.DLL ***

Security DLL file
******USAGE
Exported Function: GenerateKeyExOpt

  int GenerateKeyExOpt(
  const unsigned char*  ipSeedArray,            // Array for the seed (bytes) [in]
  unsigned int          iSeedArraySize,         // Length of the array for the seed [in]
  const unsigned int    iSecurityLevel,         // Security level [in]
  const char*           ipVariant,              // Name of the active variant  (string) [in]
  const char*           ipOptions,              // Optional parameter which might be used for OEM specific information [in]
  unsigned char*        iopKeyArray,            // Array for the key (bytes) [in, out]
  unsigned int          iMaxKeyArraySize,       // Maximum length of the array for the key [in]
  unsigned int&         oActualKeyArraySize )    // Length of the key [out]

return values (int):
0 := OK (no error)
1 := Buffer too small
2 := Invalid Security level
3 := Invalid Variant
4 := Unspecified error
*********************************************
History:
File Version:1.5.0.2	first release
File Version:1.5.0.3	(P_SPA2VOLVO2,P_OFFSL2 and P_RNM2 variants added) (2022.05.24.)
File Version:1.5.1.0	(P_SPA2VOLVO3 variant(16B) added,
							special default key query added,
							P_VW1 variant added,
							FBL level added to P_RNM2,
							buffer end aligment bug fixed ) (2022.12.09.)

******************
Variant string:
	"P_VW1"				s.Level:0x03 Algo:ADDWCR  s.Level:0x11 Algo:ADDWCR
	"P_GBMS"			s.Level:0x21 Algo:EESE  s.Level:0x01 Algo:EESE
	"P_GSBMS"			s.Level:0x21 Algo:EESE  s.Level:0x01 Algo:EESE
	"P_SPA2VOLVO1"		s.Level:0x21 Algo:EESE  s.Level:0x01 Algo:EESE
	"P_CSM1"			s.Level:0x61 Algo:CTBM  
	"P_BMW2015"			s.Level:0x61 Algo:CTBM  s.Level:0x01 Algo:CTBM
	"P_BMW2021"			s.Level:0x61 Algo:CTBM  s.Level:0x01 Algo:CTBM
	"P_SPA2VOLVO2"		s.Level:0x61 Algo:CAFSAM (use default internal parameter in case empty ipOptions); s.Level:0x01 Algo:EESE
	"P_OFFSL2"			s.Level:0x61 Algo:CAFSAM (use default internal parameter in case empty ipOptions)
	"P_RNM2"			s.Level:0x61 Algo:CAFSAM (use default internal parameter in case empty ipOptions); s.Level:0x47 Algo:XOR
	"P_SPA2VOLVO3"		s.Level:0x61 Algo:CAFSAM (use default internal parameter in case empty ipOptions); s.Level:0x01 Algo:EESE

	"A_CAFSAM"		s.Level:any Algo:CAFSAM OPTION: additional (internal)seed bytes
	""   (empty)	s.Level:any Algo:CTBM
	unknown string:	s.Level:any Algo:invert bytes
******************	
Options string:
byte array list coded in ASCII numbers (two hexadecimal digits/bytes with or without space separator) 
example: 1FCA0078		or   1F CA 00 78
*********************************************
The file name is constant here, therefore the file versions must be checked by the operating system.
If the test software uses different releases then it is proposed to rename the file versions for easy change.